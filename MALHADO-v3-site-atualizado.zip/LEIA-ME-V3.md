# MALHADO — versão 3

## O que mudou

A abertura mantém “Quem não é visto, não é lembrado”, agora com o complemento “Seu próximo cliente precisa conhecer o seu negócio”. O convite principal é “Quero atrair mais clientes”.

A página inicial ganhou uma seção em três momentos — descoberta, interesse e oportunidade — com explicações expansíveis sobre como cada serviço contribui para o objetivo. Os textos das páginas Serviços, O estúdio e Contato e as recomendações interativas foram ajustados para essa direção. O objetivo comercial é aproximar a marca de potenciais clientes; não há promessa de alcance, seguidores ou vendas garantidos.

O visual, a paleta, a estrutura principal e os efeitos da versão anterior foram preservados. Valores e pacotes não foram alterados.

## Visualizar

Abra `ABRA-A-PREVIA.html` no seu navegador. Baixe o arquivo e abra-o; o visualizador de anexos do aplicativo pode restringir scripts e imagens externas.

A prévia inclui os textos, estilos e interações. Os três PNGs da identidade original não foram incorporados durante a montagem porque seu download não foi possível neste ambiente. A prévia tenta carregá-los diretamente do repositório público, sem desenhar outra logo.

### Resolver a logo dentro da própria prévia

Use o botão “Prévia · logo e arquivos”, no canto inferior esquerdo. Esse painel não faz parte do site publicado.

O painel mostra se cada imagem original está disponível. Com internet, é possível tentar carregar os arquivos do GitHub. Caso a rede ou o navegador bloqueie o carregamento, “Abrir original” leva à imagem de referência: salve o PNG e selecione-o no campo correspondente. Também é possível selecionar os originais que você já tem no computador.

Depois que os três PNGs estiverem disponíveis, os botões abaixo são liberados:

- **Salvar prévia com logos**: gera um HTML com as imagens incorporadas, que pode ser aberto sem internet. Links externos e mensagens continuam dependendo de conexão.
- **Baixar site com as logos**: gera um novo ZIP que inclui os três PNGs junto dos arquivos atualizados.

A seleção dos arquivos é processada somente no navegador. Nenhum PNG selecionado é enviado para um servidor. O painel não salva automaticamente os arquivos no seu computador: use um dos botões de download para preservar a versão incorporada.

## Identidade original

Os arquivos referenciados são os originais do repositório:

- `logo.png.png`: marca azul para o cabeçalho;
- `logobranca.png.png`: marca branca para o rodapé;
- `logomenor.png.png`: símbolo para o ícone da aba.

Fontes:
https://raw.githubusercontent.com/emillymalhado/site-malhado-cstudio/main/logo.png.png
https://raw.githubusercontent.com/emillymalhado/site-malhado-cstudio/main/logobranca.png.png
https://raw.githubusercontent.com/emillymalhado/site-malhado-cstudio/main/logomenor.png.png

Não foram criadas versões redesenhadas, marcas substitutas ou imagens de teste para a entrega. Em uma falha de carregamento, o site mostra apenas o nome do estúdio em texto comum para evitar um cabeçalho completamente vazio. Esse texto não é apresentado como a logo original.

**Limitação desta entrega:** o ZIP anexado contém os arquivos atualizados, mas não os três PNGs. O carregamento externo das logos originais não foi validado no ambiente de testes. A importação de PNGs e a exportação de HTML/ZIP foram verificadas com um pequeno arquivo técnico de teste, que não foi incluído na entrega e não representa a marca.

## Publicar

Faça uma cópia de segurança do repositório. Envie o conteúdo da pasta `malhado-site` para a mesma pasta já publicada, preservando a configuração de hospedagem existente. Não crie uma pasta extra `malhado-site` dentro da raiz pública.

**Não apague os três PNGs originais que já existem no repositório.** Este ZIP atualiza HTML, CSS e JavaScript; as imagens existentes devem permanecer ao lado de `index.html` e `sobre.html`. Outra opção é usar “Baixar site com as logos” na prévia, depois de carregar os três arquivos.

O caminho `sobre.html` e os endereços das demais páginas foram mantidos. `portifolio.html` e `SITE.html` continuam como redirecionamentos de compatibilidade.

Esta entrega não alterou o site publicado nem acessou sua conta do GitHub.

## Formulário: funcionamento preservado

O formulário prepara uma mensagem para o visitante revisar e enviar por WhatsApp ou aplicativo de e-mail. Ele **não envia e-mail automaticamente** e não exibe confirmação falsa de entrega. O visitante ainda precisa concluir o envio no aplicativo escolhido.

Não foi contratado ou configurado um serviço de envio. Não houve disparo real de mensagens ou confirmação de recebimento na caixa de entrada.

## Conteúdo que depende da proprietária

Confirme contatos, valores, escopo, prazos e disponibilidade antes de publicar. Portfólio, métricas e depoimentos devem ser preenchidos somente com materiais reais e autorizados. A revisão não inventou clientes nem resultados.

## Verificações

O relatório está em `testes/verificacoes-v3.json`.

Foram verificadas 12 páginas em seis larguras, de 320 a 1920 pixels, totalizando 72 combinações sem rolagem horizontal nos testes. As 47 verificações de comportamento incluem explicações expansíveis, seleção de objetivos, passagem do objetivo para o contato, menu móvel, teclado nas etapas do método, redução de movimento, preparação de mensagens e ferramentas de importação/exportação da prévia.

As verificações foram executadas em Chromium, com o conteúdo incorporado para renderização local. A política do ambiente bloqueou navegação HTTP/file e a obtenção das imagens externas. Os testes não equivalem a validação do site publicado, de navegadores diferentes, de celulares físicos, da logo original carregada pela rede ou do recebimento de e-mails.
